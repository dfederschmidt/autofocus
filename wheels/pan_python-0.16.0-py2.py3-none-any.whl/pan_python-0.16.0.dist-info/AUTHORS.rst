pan-python is written and maintained by Kevin Steves and various
contributors:

Patches and Suggestions
-----------------------

- Brian Torres-Gil
- Jonathan Kaplan
- Andrew Stanton
- Darlene Wong
- Michael Richardson
